Housetory inventory evidence package
====================================

Household: Housetory Phase Five
Generated: 2026-11-05T15:17:40.585871+00:00 (UTC)
Scope: 2 selected items
Items: 2 · units: 3

This package records what is currently recorded in Housetory.
It is not a physical stocktake, an appraisal, an insurance acceptance,
a claim or a guarantee of coverage. Missing information is marked, not
invented. Currencies are kept separate and never converted.

Main report: housetory-inventory-evidence-20261105-0839e2d9.pdf
Spreadsheet: housetory-inventory-evidence-20261105-0839e2d9.csv
Manifest: manifest.json

Evidence files are under documents/ and photos/. The manifest maps each
file to its item/document, role, SHA-256 and byte count. Original means
the exact stored upload bytes; normalized/download means the safe or
cleaned derivative. A missing file is listed in manifest.json and in the
report notes rather than silently omitted.

No borrower names, loan notes, purchase notes or document notes are included.
The package is private and should be stored securely. It is not uploaded
or shared automatically by Housetory.
